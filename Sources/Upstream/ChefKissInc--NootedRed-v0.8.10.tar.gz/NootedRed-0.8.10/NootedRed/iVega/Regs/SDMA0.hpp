// Copyright © 2024-2025 ChefKiss. Licensed under the Thou Shalt Not Profit License version 1.5.
// See LICENSE for details.

#pragma once
#include <IOKit/IOTypes.h>

constexpr UInt32 SDMA0_POWER_CNTL             = 0x1A;
constexpr UInt32 SDMA0_CLK_CTRL               = 0x1B;
constexpr UInt32 SDMA0_CHICKEN_BITS           = 0x1D;
constexpr UInt32 SDMA0_GB_ADDR_CONFIG         = 0x1E;
constexpr UInt32 SDMA0_GB_ADDR_CONFIG_READ    = 0x1F;
constexpr UInt32 SDMA0_F32_CNTL               = 0x2A;
constexpr UInt32 SDMA0_UTCL1_WATERMK          = 0x3D;
constexpr UInt32 SDMA0_UTCL1_PAGE             = 0x48;
constexpr UInt32 SDMA0_GFX_RB_WPTR_POLL_CNTL  = 0x87;
constexpr UInt32 SDMA0_GFX_IB_CNTL            = 0x8A;
constexpr UInt32 SDMA0_GFX_MINOR_PTR_UPDATE   = 0xB5;
constexpr UInt32 SDMA0_RLC0_RB_WPTR_POLL_CNTL = 0x147;
constexpr UInt32 SDMA0_RLC0_IB_CNTL           = 0x14A;
constexpr UInt32 SDMA0_RLC1_RB_WPTR_POLL_CNTL = 0x1A7;
constexpr UInt32 SDMA0_RLC1_IB_CNTL           = 0x1AA;

constexpr UInt32 SDMA0_F32_CNTL_HALT = 0x1;

constexpr UInt32 SDMA0_POWER_CNTL_BASE_IDX             = 0;
constexpr UInt32 SDMA0_CLK_CTRL_BASE_IDX               = 0;
constexpr UInt32 SDMA0_CHICKEN_BITS_BASE_IDX           = 0;
constexpr UInt32 SDMA0_GB_ADDR_CONFIG_BASE_IDX         = 0;
constexpr UInt32 SDMA0_GB_ADDR_CONFIG_READ_BASE_IDX    = 0;
constexpr UInt32 SDMA0_UTCL1_WATERMK_BASE_IDX          = 0;
constexpr UInt32 SDMA0_UTCL1_PAGE_BASE_IDX             = 0;
constexpr UInt32 SDMA0_GFX_RB_WPTR_POLL_CNTL_BASE_IDX  = 0;
constexpr UInt32 SDMA0_GFX_IB_CNTL_BASE_IDX            = 0;
constexpr UInt32 SDMA0_GFX_MINOR_PTR_UPDATE_BASE_IDX   = 0;
constexpr UInt32 SDMA0_RLC0_RB_WPTR_POLL_CNTL_BASE_IDX = 0;
constexpr UInt32 SDMA0_RLC0_IB_CNTL_BASE_IDX           = 0;
constexpr UInt32 SDMA0_RLC1_RB_WPTR_POLL_CNTL_BASE_IDX = 0;
constexpr UInt32 SDMA0_RLC1_IB_CNTL_BASE_IDX           = 0;
