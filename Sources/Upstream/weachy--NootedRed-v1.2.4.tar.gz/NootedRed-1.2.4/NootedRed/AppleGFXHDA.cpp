// External Audio Patches
//
// Copyright (C) 2022-2026  ChefKiss.
//
// Licensed under the ChefKiss Open Knowledge License version 1.
//
// This work is licensed to you under the terms of the ChefKiss Open Knowledge
// License, either version 1 of the License, or (at your option) any later
// version published by ChefKiss.
//
// This work may not be used to train or develop artificial intelligence,
// and may not be used with artificial intelligence in any other way. See
// the ChefKiss Open Knowledge License for details.
//
// This work is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// ChefKiss Open Knowledge License for more details.
//
// You should have received a copy of the ChefKiss Open Knowledge License
// along with this work.  If not, see https://git.chefkiss.dev/ChefKiss/OpenKnowledge/raw/branch/master/LICENSE-v1.md.

#include <AppleGFXHDA.hpp>
#include <Headers/kern_iokit.hpp>
#include <Headers/kern_patcher.hpp>
#include <Headers/kern_util.hpp>
#include <Kexts.hpp>
#include <NRed.hpp>
#include <libkern/OSTypes.h>

static constexpr UInt32 AMDVendorID        = 0x1002;
static constexpr UInt32 RavenHDMIDeviceID  = 0x15DE;
static constexpr UInt32 RenoirHDMIDeviceID = 0x1637;

static AppleGFXHDA moduleInstance;

namespace
{

    // A function that another plugin already routed has a jump written at its entry: EB rel8 (short), E9 rel32
    // (long) or FF 25 (Lilu's slotted long jump).  Lilu refuses to mix jump types on one function and panics
    // from inside routeMultipleLong, so detect the previous route and leave that symbol alone.  AppleALC is
    // known to route AppleGFXHDAController::probe, which otherwise makes NootedRed panic during boot.
    bool isAlreadyRouted(KernelPatcher& patcher, const size_t id, const char* const symbol,
                         const mach_vm_address_t slide, const size_t size)
    {
        const auto from = patcher.solveSymbol(id, symbol, slide, size);
        if (from == 0) {
            patcher.clearError();
            return false;
        }

        const auto* const bytes = reinterpret_cast<const UInt8*>(from);
        return bytes[0] == 0xE9 || bytes[0] == 0xEB || (bytes[0] == 0xFF && bytes[1] == 0x25);
    }

}    // namespace

AppleGFXHDA& AppleGFXHDA::singleton() { return moduleInstance; }

void AppleGFXHDA::processKext(KernelPatcher& patcher, size_t id, mach_vm_address_t slide, size_t size)
{
    if (kextAppleGFXHDA.loadIndex != id) { return; }

    NRed::singleton().hwLateInit();

    KernelPatcher::SolveRequest solveRequests[] = {
        {"__ZN34AppleGFXHDAFunctionGroupATI_Tahiti10gMetaClassE", this->orgFunctionGroupTahiti},
        {"__ZN26AppleGFXHDAWidget_1002AAA010gMetaClassE", this->orgWidget1002AAA0},
    };
    PANIC_COND(!patcher.solveMultiple(id, solveRequests, slide, size, true), "AGFXHDA", "Failed to solve symbols");

    // Another plugin (AppleALC routes AppleGFXHDAController::probe) may have installed a short jump on a
    // symbol we also route.  Lilu panics when a long multiroute is attempted on top of a short route, so
    // filter the already-routed symbols out; the plugin that owns them keeps handling them.
    KernelPatcher::RouteRequest routeRequests[] = {
        {"__ZN21AppleGFXHDAController5probeEP9IOServicePi", wrapProbe, this->orgProbe},
        {"__ZN31AppleGFXHDAFunctionGroupFactory27createAppleHDAFunctionGroupEP11DevIdStruct",
         wrapCreateAppleHDAFunctionGroup, this->orgCreateAppleHDAFunctionGroup},
        {"__ZN24AppleGFXHDAWidgetFactory20createAppleHDAWidgetEP11DevIdStruct", wrapCreateAppleHDAWidget,
         this->orgCreateAppleHDAWidget},
    };

    auto routed = true;
    for (auto& request : routeRequests) {
        if (isAlreadyRouted(patcher, id, request.symbol, slide, size)) {
            SYSLOG("AGFXHDA", "`%s` is already routed by another plugin; leaving it to that plugin",
                   request.symbol);
            continue;
        }

        routed &= patcher.routeMultipleLong(id, &request, 1, slide, size);
    }

    PANIC_COND(!routed, "AGFXHDA", "Failed to route symbols");
}

IOService* AppleGFXHDA::wrapProbe(IOService* that, IOService* provider, SInt32* score)
{
    const auto dev = OSDynamicCast(IOPCIDevice, provider);
    if (dev == nullptr) { return FunctionCast(wrapProbe, singleton().orgProbe)(that, provider, score); }

    const auto vendorID = WIOKit::readPCIConfigValue(dev, WIOKit::kIOPCIConfigVendorID);
    const auto deviceID = WIOKit::readPCIConfigValue(dev, WIOKit::kIOPCIConfigDeviceID);
    if (vendorID != AMDVendorID || (deviceID != RavenHDMIDeviceID && deviceID != RenoirHDMIDeviceID)) {
        DBGLOG("GFXHDA", "Device is not Raven or Renoir, calling org.");
        return FunctionCast(wrapProbe, singleton().orgProbe)(that, provider, score);
    }

    provider->setName("HDAU");

    UInt8 bytes[] = {0x00};
    dev->setProperty("built-in", bytes, sizeof(bytes));

    that->setProperty("NootedRedGFXHDA", bytes, sizeof(bytes));

    singleton().controller.provider(that)                   = provider;
    singleton().controller.vendorID(that)                   = vendorID;
    singleton().controller.deviceID(that)                   = deviceID;
    singleton().controller.integratedCodecAddressMask(that) = 0x1;
    singleton().controller.codecAddressMask(that)           = 0x1;
    singleton().controller.useRirb(that)                    = true;
    singleton().controller.timeIntervalFilterOrder(that)    = 9;
    singleton().controller.intIndex(that)                   = 1;
    singleton().controller.inputSampleLatency(that)         = 1;
    singleton().controller.outputSampleLatency(that)        = 1;
    singleton().controller.inputSafetyOffset(that)          = 0x28;
    singleton().controller.outputSafetyOffset(that)         = 0x28;
    singleton().controller.inputSafetyOffsetLowPower(that)  = 0x28;
    singleton().controller.outputSafetyOffsetLowPower(that) = 0x28;
    singleton().controller.inputEntrySize(that)             = 0x3000;
    singleton().controller.outputEntrySize(that)            = 0x3000;
    singleton().controller.regAccessReady(that)             = true;

    *score = 1;

    char hdaGfxBytes[] = "onboard-1";
    dev->setProperty("hda-gfx", hdaGfxBytes, sizeof(hdaGfxBytes));

    DBGLOG("GFXHDA", "Initialised Raven or Renoir device.");

    return that;
}

void* AppleGFXHDA::wrapCreateAppleHDAFunctionGroup(void* devId)
{
    const auto vendorID = getMember<UInt16>(devId, 0x2);
    const auto deviceID = getMember<UInt32>(devId, 0x8);
    if (vendorID == AMDVendorID && (deviceID == RavenHDMIDeviceID || deviceID == RenoirHDMIDeviceID)) {
        return singleton().orgFunctionGroupTahiti->alloc();
    }
    return FunctionCast(wrapCreateAppleHDAFunctionGroup, singleton().orgCreateAppleHDAFunctionGroup)(devId);
}

void* AppleGFXHDA::wrapCreateAppleHDAWidget(void* devId)
{
    auto vendorID = getMember<UInt16>(devId, 0x2);
    auto deviceID = getMember<UInt32>(devId, 0x8);
    if (vendorID == AMDVendorID && (deviceID == RavenHDMIDeviceID || deviceID == RenoirHDMIDeviceID)) {
        return singleton().orgWidget1002AAA0->alloc();
    }
    return FunctionCast(wrapCreateAppleHDAFunctionGroup, singleton().orgCreateAppleHDAFunctionGroup)(devId);
}
