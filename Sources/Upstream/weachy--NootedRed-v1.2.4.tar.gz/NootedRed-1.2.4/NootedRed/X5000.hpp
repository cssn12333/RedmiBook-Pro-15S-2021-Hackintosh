// AMDRadeonX5000 Patches
//
// Copyright (C) 2022-2026  ChefKiss.
//
// Licensed under the ChefKiss Open Knowledge License version 1.
//
// This work is licensed to you under the terms of the ChefKiss Open Knowledge
// License, either version 1 of the License, or (at your option) any later
// version published by ChefKiss.
//
// This work may not be used to train or develop artificial intelligence,
// and may not be used with artificial intelligence in any other way. See
// the ChefKiss Open Knowledge License for details.
//
// This work is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// ChefKiss Open Knowledge License for more details.
//
// You should have received a copy of the ChefKiss Open Knowledge License
// along with this work.  If not, see https://git.chefkiss.dev/ChefKiss/OpenKnowledge/raw/branch/master/LICENSE-v1.md.

#pragma once
#include <GPUDriversAMD/Accel/HWAlignManager.hpp>
#include <GPUDriversAMD/Accel/HWDisplay.hpp>
#include <GPUDriversAMD/Accel/HWEngine.hpp>
#include <GPUDriversAMD/AddrLib.hpp>
#include <GPUDriversAMD/FB/FramebufferInfo.hpp>
#include <GPUDriversAMD/FB/SurfaceInfo.hpp>
#include <Headers/kern_patcher.hpp>
#include <IOKit/graphics/IOFramebuffer.h>
#include <PenguinWizardry/ObjectField.hpp>

class X5000
{
    ObjectField<void*>             pm4EngineField;
    ObjectField<void*>             sdma0EngineField;
    ObjectField<UInt32>            supportedDisplayCountField;
    ObjectField<UInt32>            seCountField;
    ObjectField<UInt32>            shCountField;
    ObjectField<UInt32>            hwMaxCUsField;
    ObjectField<bool>              hasUVD0Field;
    ObjectField<bool>              hasVCEField;
    ObjectField<bool>              hasVCN0Field;
    ObjectField<bool>              hasSDMAPagingQueueField;
    ObjectField<bool>              hasGetAllClockLimitsField;
    ObjectField<bool>              dccDisplayableSupportField;
    ObjectField<UInt32>            familyTypeField;
    ObjectField<Gfx9ChipSettings>  chipSettingsField;
    ObjectField<void*>             hwChannelHWInterfaceField;
    ObjectField<mach_vm_address_t> hwChannelSubmitCommandBuffer;
    OSMetaClass*                   pm4EngineMC{nullptr};
    OSMetaClass*                   sdmaEngineMC{nullptr};
    mach_vm_address_t              orgGFX9SetupAndInitializeHWCapabilities{0};
    mach_vm_address_t              orgGetHWChannel{0};
    mach_vm_address_t              orgAdjustVRAMAddress{0};
    mach_vm_address_t              orgObtainAccelChannelGroup{0};
    mach_vm_address_t              orgHwlConvertChipFamily{0};
    mach_vm_address_t              orgPM4SubmitCommandBuffer{0};
    mach_vm_address_t              orgAllocateLargeBlocks{0};
    mach_vm_address_t              orgRTHardwareDidStart{0};
    UInt32                         gfxOffSupportedOffset{0x206b8};
    void                           (*notifyGfxAccess)(void*){nullptr};
    UInt64                         (*orgTotalFreeMemory)(void*){nullptr};
    bool                           (*orgAllocate)(void*, void*, UInt64, UInt64, UInt32, bool, UInt32, UInt32){nullptr};
    bool                           (*orgAllocateNonContiguous)(void*, void*, UInt64, UInt64, UInt32, bool, bool, UInt64,
                                                               UInt32, UInt32){nullptr};

public:
    static X5000& singleton();

    X5000();

    void processKext(KernelPatcher& patcher, size_t id, mach_vm_address_t slide, size_t size);

    // Clears/sets the VCN0 capability on the AMD hardware object.  Used by VCNBridge when the native engine
    // fails to initialise after the capability was advertised.
    void setVCN0Capability(void* self, bool enabled);

private:
    static bool   allocateHWEngines(void* self);
    static void   wrapSetupAndInitializeHWCapabilities(void* self);
    static void*  wrapGetHWChannel(void* self, AMDHWEngineType engineType, UInt32 ringId);
    static void   initializeFamilyType(void* self);
    static void*  allocateAMDHWDisplay(void* self);
    static UInt64 wrapAdjustVRAMAddress(void* self, UInt64 addr);
    static bool   wrapAllocateLargeBlocks(void* self, void* elem, UInt64 size, UInt64 align, UInt64 minBlockSize,
                                          UInt32 orig, UInt32 opType, bool onlyNonVisible);
    static void   wrapRTHardwareDidStart(void* self);
    static UInt32 returnZero();
    static void*  wrapObtainAccelChannelGroup(void* self, UInt32 priority);
    static void*  wrapObtainAccelChannelGroup1304(void* self, UInt32 priority, void* task);
    static UInt32 wrapHwlConvertChipFamily(void* self, UInt32 family, UInt32 revision);
    static UInt32 computeSubmitCommandBuffer(void* self, void* info);
    static bool   fixedGetDisplayInfo(AMDRadeonX5000_AMDHWDisplay* self, UInt32 fbIndex, bool isCRTEnabled,
                                      bool ignoreCRTOffsetCheck, IOFramebuffer* fb, FramebufferInfo* fbInfo);
    static void   fixedGetSurfaceInfo(AMDRadeonX5000_AMDHWAlignManager* self, AMD_SURFACE_INFO_STRUCT* pStruct);
};
