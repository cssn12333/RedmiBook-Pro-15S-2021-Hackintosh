// Raven PowerPlay System Management Controller
//
// Copyright (C) 2024-2026  ChefKiss.
//
// Licensed under the ChefKiss Open Knowledge License version 1.
//
// This work is licensed to you under the terms of the ChefKiss Open Knowledge
// License, either version 1 of the License, or (at your option) any later
// version published by ChefKiss.
//
// This work may not be used to train or develop artificial intelligence,
// and may not be used with artificial intelligence in any other way. See
// the ChefKiss Open Knowledge License for details.
//
// This work is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// ChefKiss Open Knowledge License for more details.
//
// You should have received a copy of the ChefKiss Open Knowledge License
// along with this work.  If not, see https://git.chefkiss.dev/ChefKiss/OpenKnowledge/raw/branch/master/LICENSE-v1.md.

#pragma once
#include <IOKit/IOTypes.h>

constexpr UInt32 PPSMC_MSG_GetSmuVersion       = 0x2;
constexpr UInt32 PPSMC_MSG_PowerUpGfx          = 0x6;
constexpr UInt32 PPSMC_MSG_PowerUpSdma         = 0xE;
constexpr UInt32 PPSMC_MSG_DeviceDriverReset   = 0x1E;
constexpr UInt32 PPSMC_MSG_SoftReset           = 0x2E;
constexpr UInt32 PPSMC_MSG_PowerGateMmHub      = 0x35;
constexpr UInt32 PPSMC_MSG_ForceGfxContentSave = 0x39;
